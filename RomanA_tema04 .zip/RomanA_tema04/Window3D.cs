﻿//Roman_Adi 3134A

using OpenTK;
using System;
using System.Drawing;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using OpenTK.Graphics;
using System.IO;
using System.Collections.Generic;



namespace Project
{
    class Window3D : GameWindow
    {
        private KeyboardState previousKeyboard;
        private MouseState previousMouse;

        KeyboardState lastKeyPress;
        Axes axes = new Axes();
        Cube cube = new Cube();
        bool colorShape= true;
 
        private List<Object> fallObject;
        private Object objy;

        private readonly Camera3DIsometric cam;
        private readonly Grid grid;

        private bool GRAVITY = true;



        public Window3D() : base(900, 600, new GraphicsMode(32, 24, 0, 8))
        {
            VSync = VSyncMode.On;
            cam = new Camera3DIsometric();
            grid = new Grid();
            fallObject = new List<Object>();
            //objy = new MassiveObject(Color.Yellow);

        }



        /**Setare mediu OpenGL și încarcarea resurselor (dacă e necesar) - de exemplu culoarea de
   fundal a ferestrei 3D.
   Atenție! Acest cod se execută înainte de desenarea efectivă a scenei 3D. */
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            GL.Enable(EnableCap.DepthTest);
            GL.DepthFunc(DepthFunction.Less);
            GL.Hint(HintTarget.PolygonSmoothHint, HintMode.Nicest);


        }

        /**Inițierea afișării și setarea viewport-ului grafic. Metoda este invocată la redimensionarea
           ferestrei. Va fi invocată o dată și imediat după metoda ONLOAD()!
           Viewport-ul va fi dimensionat conform mărimii ferestrei active (cele 2 obiecte pot avea și mărimi 
           diferite). */
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            GL.ClearColor(Color.Black);


            GL.Viewport(0, 0,this.Width, this.Height);

            double aspect_ratio = Width / (double)Height;

            Matrix4 perspective = Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver4, (float)aspect_ratio, 1, 64);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref perspective);

            // set the eye
            cam.SetCamera();
        }

        /** Secțiunea pentru "game logic"/"business logic". Tot ce se execută în această secțiune va fi randat
            automat pe ecran în pasul următor - control utilizator, actualizarea poziției obiectelor, etc. */
        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

            KeyboardState keyboard = Keyboard.GetState();
            MouseState mouse = Mouse.GetState();

            // Se utilizeaza mecanismul de control input oferit de OpenTK (include perifcerice multiple, mai ales pentru gaming - gamepads, joysticks, etc.).
            if (keyboard[Key.Escape])
            {
                Exit();
                return;
            }else if (keyboard[OpenTK.Input.Key.C] && !keyboard.Equals(lastKeyPress))
            {
                // Ascundere comandată, prin apăsarea unei taste - cu verificare de remanență! Timpul de reacțieuman << calculator.
                if (colorShape == true)
                {
                    colorShape = false;
                }
                else
                {
                    colorShape = true;
                }
            }
            lastKeyPress = keyboard;

            // camera control (isometric mode)
            if (mouse.LeftButton == ButtonState.Pressed)
            {
                cam.MoveLeft();
            }
            // camera control (isometric mode)
            if (mouse.RightButton == ButtonState.Pressed)
            {
                cam.MoveRight();
            }

            if(mouse[MouseButton.Left] && !previousMouse[MouseButton.Left])
            {
                fallObject.Add(new Object(GRAVITY));
            }

            if (mouse[MouseButton.Right] && !previousMouse[MouseButton.Right])
            {
                fallObject.Clear();
            }

            if (keyboard[Key.G] && !previousKeyboard[Key.G])
            {
                    GRAVITY = !GRAVITY;
            }

            foreach (Object obj in fallObject)
            {
                obj.UpdatePosition(GRAVITY);
            }
            previousKeyboard = keyboard;
            previousMouse = mouse;

            //GL.Flush();
            //SwapBuffers();
        }

        /** Secțiunea pentru randarea scenei 3D. Controlată de modulul logic din metoda ONUPDATEFRAME().
            Parametrul de intrare "e" conține informatii de timing pentru randare. */
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            Matrix4 lookat = Matrix4.LookAt(15, 50, 15, 0, 0, 0, 0, 1, 0);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref lookat);

            grid.Draw();
            axes.Draw();

            foreach (Object obj in fallObject)
            {
                obj.Draw();
            }

            //objy.Draw();

            
            //Laborator 3
            //axes.Draw();

            //List<Color> pallete1 = new List<Color>();
            //pallete1.Add(color1);
            //pallete1.Add(color2);
            //pallete1.Add(color3);

            //List<Color> pallete2 = new List<Color>();
            //pallete2.Add(color4);
            //pallete2.Add(color5);
            //pallete2.Add(color6);



            //cube.drawCube();
            //drawCube(color1);

            //pentru lab 4 ex 3
            //drawCube(getRendomColor());

            //if (colorShape == true)
            //{
            //    drawTriangle(pallete1);
            //}
            //else
            //{
            //    drawTriangle(pallete2);
            //}


            SwapBuffers();
        }

        //pentru laboratorul 4
        //private void drawCube(Color color)
        //{
        //    GL.Begin(PrimitiveType.Quads);
        //    GL.Color3(color);
        //    var coordonates = readFromFile("cubeCoordonates.txt");
        //    for (int i = 0; i < coordonates.Count; i++)
        //    {
        //        var currentVert = coordonates[i];

        //        GL.Vertex3(currentVert);

        //    }
        //    GL.End();

            //ex 2 lab 4
            //GL.Begin(PrimitiveType.Quads);

            //GL.Color3(Color.Silver);
            //GL.Vertex3(-1.0f, -1.0f, -1.0f);
            //GL.Vertex3(-1.0f, 1.0f, -1.0f);
            //GL.Vertex3(1.0f, 1.0f, -1.0f);
            //GL.Vertex3(1.0f, -1.0f, -1.0f);

            //GL.Color3(Color.Honeydew);
            //GL.Vertex3(-1.0f, -1.0f, -1.0f);
            //GL.Vertex3(1.0f, -1.0f, -1.0f);
            //GL.Vertex3(1.0f, -1.0f, 1.0f);
            //GL.Vertex3(-1.0f, -1.0f, 1.0f);

            //GL.Color3(Color.Moccasin);

            //GL.Vertex3(-1.0f, -1.0f, -1.0f);
            //GL.Vertex3(-1.0f, -1.0f, 1.0f);
            //GL.Vertex3(-1.0f, 1.0f, 1.0f);
            //GL.Vertex3(-1.0f, 1.0f, -1.0f);

            //GL.Color3(Color.IndianRed);
            //GL.Vertex3(-1.0f, -1.0f, 1.0f);
            //GL.Vertex3(1.0f, -1.0f, 1.0f);
            //GL.Vertex3(1.0f, 1.0f, 1.0f);
            //GL.Vertex3(-1.0f, 1.0f, 1.0f);

            //GL.Color3(Color.PaleVioletRed);
            //GL.Vertex3(-1.0f, 1.0f, -1.0f);
            //GL.Vertex3(-1.0f, 1.0f, 1.0f);
            //GL.Vertex3(1.0f, 1.0f, 1.0f);
            //GL.Vertex3(1.0f, 1.0f, -1.0f);

            //GL.Color3(Color.ForestGreen);
            //GL.Vertex3(1.0f, -1.0f, -1.0f);
            //GL.Vertex3(1.0f, 1.0f, -1.0f);
            //GL.Vertex3(1.0f, 1.0f, 1.0f);
            //GL.Vertex3(1.0f, -1.0f, 1.0f);

            //GL.End();
      //  }

        //pentru laboratorul 3
        //private void drawTriangle(List<Color> colors)
        //{
        //    //vertexuri din fiser
        //    var coordonates = readFromFile("triangleCoordonates.txt");

        //    GL.Begin(PrimitiveType.Triangles);
        //    for (int i = 0; i < coordonates.Count; i++)
        //    {
        //        var currentVert = coordonates[i];
        //        var currentColor = colors[i];

        //        GL.Color3(currentColor);
        //        GL.Vertex3(currentVert);

        //    }
        //    GL.End();

        //    //pentru schimbarea culorii la apasarea unei taste 

        //    //GL.Begin(PrimitiveType.Triangles);

        //    //GL.Color3(color1);
        //    //GL.Vertex2(-1.0f, 1.0f);
        //    //GL.Color3(color2);
        //    //GL.Vertex2(0.0f, -1.0f);
        //    //GL.Color3(color3);
        //    //GL.Vertex2(1.0f, 1.0f);

        //    //GL.End();

        //    //manipulat culori RGB
        //    //GL.Begin(PrimitiveType.Triangles);

        //    //GL.Color3(color1);
        //    //GL.Vertex2(-10.0f, 10.0f);
        //    //GL.Color3(Color.SpringGreen);
        //    //GL.Vertex2(10.0f, -11.0f);
        //    //GL.Color3(Color.Ivory);
        //    //GL.Vertex2(10.0f, 10.0f);

        //    //GL.End();
        //}

        public List<Vector3> readFromFile(String fileName)
        {
            List<Vector3> values = new List<Vector3>();

            try
            {
                // Open the text file using a stream reader.
                using (var sr = new StreamReader(fileName))
                {
                    // Read the stream as a string, and write the string to the console.
                    //Console.WriteLine(sr.ReadToEnd());
                    while (!sr.EndOfStream)
                    {
                        var x = sr.ReadLine().Split(' ');

                        var x0 = float.Parse(x[0].Trim());
                        var x1 = float.Parse(x[1].Trim());
                        var x2 = float.Parse(x[2].Trim());
                        values.Add(new Vector3(x0, x1, x2));
                    }
                    
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
            return values;
        }

        private static String RGBConverter(Color c)
        {
            return "RGB(" + c.R.ToString() + "," + c.G.ToString() + "," + c.B.ToString() + ")";
        }

        //lab 4 ex 3
        private Color getRendomColor()
        {
            Random r = new Random();
            int genR = r.Next(0, 255);
            int genG = r.Next(0, 255);
            int genB = r.Next(0, 255);
            Color col = Color.FromArgb(genR, genG, genB);

            return col;
        }
    }
}
