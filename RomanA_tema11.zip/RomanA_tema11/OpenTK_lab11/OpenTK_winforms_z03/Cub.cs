﻿//Roman Adi 3134A

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;
using System.IO;

namespace OpenTK_winforms_z03
{
    class Cub
    {
        List<Vector3> coordList;
        bool afisare;
        PolygonMode polMode;
        int OX;
        int OY;
        int OZ;

        int OX1=1;
        int OY1=1;
        int OZ1=1;

        public Cub()
        {
            coordList = new List<Vector3>();
            afisare = false;
            polMode = PolygonMode.Fill;
            citireFisier("D:/OpenTK_lab11/dateCub.txt");

        }

        public void citireFisier(string numeFisier)
        {
            try
            {
                using (StreamReader sr = new StreamReader(numeFisier))
                {
                    while (!sr.EndOfStream)
                    {
                        String[] buff = sr.ReadLine().Split(',');
                        coordList.Add(new Vector3(Convert.ToInt32(buff[0]), Convert.ToInt32(buff[1]), Convert.ToInt32(buff[2])));
                    }
                }
            }
            catch(IOException eIO)
            {
               // throw new Exception("Eroare la deschiderea fisierului!" + eIO.Message);
            }
            catch(Exception eGEN)
            {
                throw new Exception("Eroare generica!" + eGEN.Message);
            }
        }
        public void drawCube()
        {
            GL.PushMatrix();
            GL.Translate(OX, OY, OZ);
            GL.Scale(OX1,OY1,OZ1);
           
            if (afisare == true)
            {
                GL.LineWidth(2.0f);
                GL.PolygonMode(MaterialFace.FrontAndBack,polMode);
                GL.Begin(PrimitiveType.Quads);
                for (int i = 0; i < 24; i++)
                {
                    if (i >= 0 && i < 4)
                    {
                        if (i == 0)
                            GL.TexCoord2(0, 0);
                        if (i == 1)
                            GL.TexCoord2(0, 1);
                        if (i == 2)
                            GL.TexCoord2(1, 1);
                        if (i == 3)
                            GL.TexCoord2(1, 0);
                        GL.Color3(Color.Red);
                        GL.Normal3(0.0, 0.0, -1.0);
                    }
                    if (i >= 4 && i < 8)
                    {
                        if (i == 4)
                            GL.TexCoord2(0, 0);
                        if (i == 5)
                            GL.TexCoord2(0, 1);
                        if (i == 6)
                            GL.TexCoord2(1, 1);
                        if (i == 7)
                            GL.TexCoord2(1, 0);
                        GL.Color3(Color.Green);
                        GL.Normal3(-1.0, 0.0, 0.0);
                    }
                    if (i >= 8 && i < 12)
                    {
                        if (i == 8)
                            GL.TexCoord2(0, 0);
                        if (i == 9)
                            GL.TexCoord2(0, 1);
                        if (i == 10)
                            GL.TexCoord2(1, 1);
                        if (i == 11)
                            GL.TexCoord2(1, 0);
                        GL.Color3(Color.Yellow);
                        GL.Normal3(0.0, -1.0, 0.0);
                    }
                    if (i >= 12 && i < 16)
                    {
                        if (i == 12)
                            GL.TexCoord2(0, 0);
                        if (i == 13)
                            GL.TexCoord2(0, 1);
                        if (i == 14)
                            GL.TexCoord2(1, 1);
                        if (i == 15)
                            GL.TexCoord2(1, 0);
                        GL.Color3(Color.Blue);
                        GL.Normal3(0.0, 0.0, 1.0);
                    }
                    if (i >= 16 && i < 20)
                    {
                        if (i == 16)
                            GL.TexCoord2(0, 0);
                        if (i == 17)
                            GL.TexCoord2(0, 1);
                        if (i == 18)
                            GL.TexCoord2(1, 1);
                        if (i == 19)
                            GL.TexCoord2(1, 0);
                        GL.Color3(Color.Pink);
                        GL.Normal3(1.0, 0.0, 0.0);
                    }
                    if (i >= 20 && i < 24)
                    {
                        if (i == 20)
                            GL.TexCoord2(0, 0);
                        if (i == 21)
                            GL.TexCoord2(0, 1);
                        if (i == 22)
                            GL.TexCoord2(1, 1);
                        if (i == 23)
                            GL.TexCoord2(1, 0);
                        GL.Color3(Color.Orange);
                        GL.Normal3(0.0, 1.0, 0.0);
                    }

                    GL.Vertex3(coordList[i]);
                }
                GL.End();
                
            }GL.PopMatrix();
        }

        public void moveOXPlus()
        {
            OX = OX+2;
        }

        public void moveOXMinus()
        {
            OX--;
        }

        public void scaleOXPlus()
        {
            OX1++;
        }

        public void scaleOXMinus()
        {
            OX1--;
        }
        public void scaleOZPlus()
        {
            OZ1++;
        }

        public void scaleOZMinus()
        {
            OZ1--;
        }
        public void scaleOYPlus()
        {
            OY1++;
        }

        public void scaleOYMinus()
        {
            OY1--;
        }


        public void setAfisare()
        {
            afisare = true;
        }
        public void setAscunde()
        {
            afisare = false;
        }

        public bool getAfisare()
        {
            return afisare;
        }


    }
}
